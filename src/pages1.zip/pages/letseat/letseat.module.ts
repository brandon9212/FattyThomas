import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LetseatPage } from './letseat';

@NgModule({
  declarations: [
    LetseatPage,
  ],
  imports: [
    IonicPageModule.forChild(LetseatPage),
  ],
})
export class LetseatPageModule {}
